# Jarvsi

Voice assistant for Android. Say "hi" and it greets you, reads the weather, lists who messaged you on WhatsApp, answers out loud in a British voice, and opens apps ("open Chrome").

## Get the APK without a computer
1. Create a free GitHub repo, upload this folder's contents (keep `.github/workflows/build.yml`).
2. Open the repo's **Actions** tab, run **Build APK**, then download the `jarvsi-apk` artifact.
3. Unzip, install `app-debug.apk` (allow "install unknown apps").

Or open the folder in Android Studio and press Run.

## First-run setup (inside the app)
1. Paste your Anthropic API key (console.anthropic.com), tap step 1, allow mic, location, notifications.
2. Step 2: enable Jarvsi under notification access (lets it see WhatsApp senders).
3. Step 3: allow display over other apps (needed to open apps from the background).
4. Step 4: Start. Say "hi".

## Tips
- Settings > Battery > Jarvsi > Unrestricted, so Android does not stop it.
- Install the Google voice pack "English (UK)" in Android text-to-speech settings for the best British voice.
- Say "thanks" or "goodbye" to return to sleep. After ~2 silent listens it sleeps on its own.
- Messages are only visible while the WhatsApp notification is still on your screen.
- Only your spoken questions go to Claude. Message contents stay on the phone unless you ask it to read them aloud.
