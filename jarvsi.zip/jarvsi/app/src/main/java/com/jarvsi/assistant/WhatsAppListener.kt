package com.jarvsi.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService

/** Gives Jarvsi read access to currently shown notifications. */
class WhatsAppListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        Inbox.listener = this
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (Inbox.listener === this) Inbox.listener = null
    }
}

object Inbox {
    @Volatile
    var listener: WhatsAppListener? = null

    private val packages = setOf("com.whatsapp", "com.whatsapp.w4b")

    /** Pairs of (sender or chat, latest text) for WhatsApp notifications still on screen. */
    fun unread(): List<Pair<String, String>> {
        val l = listener ?: return emptyList()
        return try {
            l.activeNotifications
                .filter {
                    it.packageName in packages &&
                        (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0
                }
                .mapNotNull {
                    val e = it.notification.extras
                    val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString()
                        ?: return@mapNotNull null
                    val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
                    if (title == "WhatsApp") null else title to text
                }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun join(names: List<String>): String = when (names.size) {
        0 -> ""
        1 -> names[0]
        else -> names.dropLast(1).joinToString(", ") + " and " + names.last()
    }

    fun summary(): String {
        if (listener == null) {
            return "I can't see your WhatsApp messages yet. Please grant notification access."
        }
        val names = unread().map { it.first }.distinct()
        return if (names.isEmpty()) "You have no new WhatsApp messages."
        else "You have WhatsApp messages from ${join(names)}."
    }

    fun readAloud(): String {
        if (listener == null) return "I don't have notification access yet."
        val u = unread()
        if (u.isEmpty()) return "There are no new WhatsApp messages."
        return u.joinToString(" ") { "${it.first} says: ${it.second}." }
    }
}
