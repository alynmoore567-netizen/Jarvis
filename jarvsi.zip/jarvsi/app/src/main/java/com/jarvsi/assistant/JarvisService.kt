package com.jarvsi.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Calendar

class JarvisService : Service(), RecognitionListener {

    private lateinit var speaker: Speaker
    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())
    private val brain by lazy { Brain(this) }

    private var running = true
    private var commandMode = false
    private var misses = 0

    private val wakeWords = Regex("\\b(hi|hey|hello|jarvis|jarvsi)\\b")
    private val byeWords = Regex("\\b(bye|goodbye|that's all|thank you|thanks|stop listening)\\b")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvsi", "Jarvsi", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "jarvsi")
            .setContentTitle("Jarvsi is listening")
            .setContentText("Say hi to wake me")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                1, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } else {
            startForeground(1, n)
        }

        main.post {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(this)
            }
        }
        speaker = Speaker(this, onReady = { listen() }, onDone = { listen() })
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        speaker.shutdown()
        super.onDestroy()
    }

    // ---------- listening ----------

    private fun listen(delayMs: Long = 0) {
        if (!running) return
        main.postDelayed({
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            try {
                recognizer?.startListening(i)
            } catch (e: Exception) {
                listen(1500)
            }
        }, delayMs)
    }

    override fun onResults(results: Bundle?) {
        val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()?.lowercase()?.trim()
        if (heard.isNullOrEmpty()) return listen(200)

        if (!commandMode) {
            // Wake on a short utterance containing "hi" (or hey, hello, jarvsi).
            if (wakeWords.containsMatchIn(heard) && heard.split(" ").size <= 5) greet()
            else listen(200)
        } else {
            misses = 0
            handle(heard)
        }
    }

    override fun onError(error: Int) {
        if (commandMode && error != SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
            misses++
            if (misses >= 2) {
                commandMode = false
                misses = 0
            }
        }
        if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) recognizer?.cancel()
        listen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000 else 300)
    }

    // ---------- behaviour ----------

    private fun greet() {
        commandMode = true
        misses = 0
        Thread {
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val hello = when {
                hour < 12 -> "Good morning"
                hour < 17 -> "Good afternoon"
                else -> "Good evening"
            }
            val weather = try {
                Weather.report(this)
            } catch (e: Exception) {
                "I couldn't reach the weather service just now."
            }
            speaker.say("$hello. $weather ${Inbox.summary()} How may I help?")
        }.start()
    }

    private fun handle(t: String) {
        val open = Regex("^(?:please )?(?:open|launch|start)\\s+(.+)$").find(t)
        when {
            open != null -> openApp(open.groupValues[1])

            t.split(" ").size <= 4 && byeWords.containsMatchIn(t) -> {
                commandMode = false
                speaker.say("Very good. Just say hi when you need me.")
            }

            Regex("read.*messages|what did .* say|who messaged").containsMatchIn(t) ->
                Thread { speaker.say(Inbox.readAloud()) }.start()

            else -> Thread { speaker.say(brain.ask(t)) }.start()
        }
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun openApp(spoken: String) {
        if (!Settings.canDrawOverlays(this)) {
            speaker.say("I need permission to display over other apps before I can open anything.")
            return
        }
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val target = norm(spoken.removeSuffix(" app"))

        val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == target }
            ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(target) }
            ?: apps.firstOrNull {
                val l = norm(it.loadLabel(pm).toString())
                l.length >= 3 && target.contains(l)
            }

        if (hit == null) {
            speaker.say("I couldn't find an app called $spoken.")
            return
        }
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
        if (intent == null) {
            speaker.say("I couldn't launch that one.")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        commandMode = false
        speaker.say("Opening ${hit.loadLabel(pm)}.")
        main.postDelayed({ try { startActivity(intent) } catch (_: Exception) {} }, 900)
    }

    // unused RecognitionListener callbacks
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
