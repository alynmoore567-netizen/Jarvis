package com.jarvsi.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Calm British voice. [onDone] fires after each utterance so the mic can resume. */
class Speaker(
    ctx: Context,
    private val onReady: () -> Unit,
    private val onDone: () -> Unit
) {
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                t.language = Locale.UK
                val british = (t.voices ?: emptySet()).filter {
                    it.locale.language == "en" && it.locale.country == "GB"
                }
                val male = british.firstOrNull { v ->
                    listOf("gbd", "gbb", "rjs", "male").any { v.name.contains(it, true) } &&
                        !v.name.contains("female", true)
                }
                (male ?: british.firstOrNull())?.let { t.voice = it }
                t.setPitch(0.85f)
                t.setSpeechRate(0.92f)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = this@Speaker.onDone()

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = this@Speaker.onDone()
                })
                onReady()
            }
        }
    }

    fun say(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u${System.nanoTime()}")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
