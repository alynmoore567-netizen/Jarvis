package com.jarvsi.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Sends what you say to Claude using your Anthropic API key. */
class Brain(private val ctx: Context) {

    private val history = mutableListOf<Pair<String, String>>()

    private val system = "You are Jarvsi, a calm, quietly witty British butler-style voice assistant " +
        "living on the user's phone. Your replies are spoken aloud: answer in one to three short " +
        "sentences, plain words only, no markdown, no lists, no emoji."

    fun ask(text: String): String {
        val key = ctx.getSharedPreferences("jarvsi", Context.MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isBlank()) return "Please add your Anthropic API key in the Jarvsi app first."

        synchronized(history) {
            history.add("user" to text)
            while (history.size > 12) history.removeAt(0)
            // The conversation must start with a user turn.
            while (history.isNotEmpty() && history.first().first != "user") history.removeAt(0)
        }

        return try {
            val msgs = JSONArray()
            synchronized(history) {
                history.forEach { (role, content) ->
                    msgs.put(JSONObject().put("role", role).put("content", content))
                }
            }
            val body = JSONObject()
                .put("model", "claude-sonnet-5-5")
                .put("max_tokens", 300)
                .put("system", system)
                .put("messages", msgs)

            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val raw = stream.bufferedReader().readText()
            if (code !in 200..299) {
                return if (code == 401) "That API key was rejected. Please check it in the app."
                else "The service returned an error, code $code."
            }
            val reply = JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text").trim()
            synchronized(history) { history.add("assistant" to reply) }
            reply
        } catch (e: Exception) {
            "I'm afraid I couldn't reach my brain just now. Check your connection."
        }
    }
}
