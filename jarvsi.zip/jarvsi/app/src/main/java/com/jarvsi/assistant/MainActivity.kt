package com.jarvsi.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvsi", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Jarvsi"
            textSize = 30f
        })
        root.addView(TextView(this).apply {
            text = "Say \"hi\" and I'll wake up. Complete the steps below once."
            setPadding(0, 0, 0, pad)
        })

        val key = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            setText(prefs.getString("key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        root.addView(key)

        fun button(label: String, onClick: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { onClick() }
            })
        }

        button("1. Save key and allow mic, location") {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.POST_NOTIFICATIONS
                ), 1
            )
        }
        button("2. Allow WhatsApp notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("3. Allow display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("4. Start Jarvsi") {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            try {
                startForegroundService(Intent(this, JarvisService::class.java))
                Toast.makeText(this, "Jarvsi is listening. Say hi.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Complete step 1 first: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        button("Stop Jarvsi") {
            stopService(Intent(this, JarvisService::class.java))
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
