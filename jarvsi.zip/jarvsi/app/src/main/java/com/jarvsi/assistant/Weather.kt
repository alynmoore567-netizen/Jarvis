package com.jarvsi.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.location.LocationManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Weather {

    data class Place(val lat: Double, val lon: Double, val label: String)

    @SuppressLint("MissingPermission")
    fun locate(ctx: Context): Place {
        try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val best = lm.getProviders(true)
                .mapNotNull { lm.getLastKnownLocation(it) }
                .maxByOrNull { it.time }
            if (best != null) return Place(best.latitude, best.longitude, "where you are")
        } catch (_: Exception) {
        }
        return Place(6.5244, 3.3792, "in Lagos")
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "clear"
        1, 2 -> "partly cloudy"
        3 -> "overcast"
        45, 48 -> "foggy"
        in 51..57 -> "drizzling"
        in 61..67 -> "raining"
        in 71..77 -> "snowing"
        in 80..82 -> "showery"
        in 95..99 -> "stormy"
        else -> "mild"
    }

    fun report(ctx: Context): String {
        val p = locate(ctx)
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}" +
                "&current=temperature_2m,weather_code" +
                "&daily=temperature_2m_max,precipitation_probability_max" +
                "&timezone=auto&forecast_days=1"
        )
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        val body = c.inputStream.bufferedReader().readText()
        val j = JSONObject(body)
        val cur = j.getJSONObject("current")
        val temp = Math.round(cur.getDouble("temperature_2m"))
        val what = describe(cur.getInt("weather_code"))
        val daily = j.getJSONObject("daily")
        val high = Math.round(daily.getJSONArray("temperature_2m_max").getDouble(0))
        val rain = daily.getJSONArray("precipitation_probability_max").optInt(0, 0)
        val place = if (p.label == "where you are") "outside" else p.label
        return "It is $temp degrees and $what $place, with a high of $high and a $rain percent chance of rain."
    }
}
